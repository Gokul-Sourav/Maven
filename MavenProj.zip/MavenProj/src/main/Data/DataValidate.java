package main.Data;

import java.io.BufferedReader;
import java.io.FileReader;

import org.json.simple.parser.JSONParser;

public class DataValidate {
	 JSONParser parser = new JSONParser();

	public String userValid(String username, String password) {
		try{
			int count=0;
			 BufferedReader br = new BufferedReader(new FileReader("C:/Users/go391834/Desktop/Windows_to_Linux/MavenProj/userdata.json"));
			 String line = br.readLine();
			 br.close();
			 String array[]=line.split("-");
			 for(int i=0;i<array.length;i++)
			 {
				 String arr=array[i];
				 arr=arr.replaceAll("\\[|\\]", "").replaceAll("\"", "");
				 String chk[]=arr.split(",");
				 if(chk[0].equalsIgnoreCase(username))
				 {
					 if(chk[1].equals(password))
					 {
						 count++;
						 break;
					 }
				 }
			 }
			 if(count>0)
			 {
				 return "success";
			 }
			 else{
				 return "fail";
			 }
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return "fail";
		}
      
		
	}

}
