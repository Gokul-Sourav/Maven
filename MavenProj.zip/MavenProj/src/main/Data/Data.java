package main.Data;

//import org.json.simple.JSONArray;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
 



import org.json.simple.parser.JSONParser;

import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
 
public class Data {
 
    @SuppressWarnings("unchecked")
	public String userRegistered(String name,String mail,String pass) {
        JSONArray list = new JSONArray();
        list.add(name);
        list.add(pass);
        list.add(mail);

 
        try (BufferedWriter  file = new BufferedWriter(new FileWriter("C:/Users/go391834/Desktop/Windows_to_Linux/MavenProj/userdata.json",true)))
        {
            file.write(list.toString());
            file.write("-");
            //file.newLine();
            file.flush();
            file.close();
            return "SUCCESS";
 
        } catch (Exception e) {
            e.printStackTrace();
            return "fail";
        }
    }
 
}
